// Local headers
#include "program.hpp"
#include "gloom/gloom.hpp"
#include <vector>
#include <iostream>
#include <GL/gl.h>
//#include <GL/glu.h>
//#include <GL/glut.h>
#include "gloom/gloom.hpp"
#include "gloom/shader.hpp"
#include "math.h"
#include <glm/mat4x4.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/vec3.hpp>
#include <glm/gtc/matrix_transform.hpp>


glm::vec3 position = glm::vec3(0.0f,0.0f,-2.0f);
glm::vec2 rotation = glm::vec2(0.0f, 0.0f);

void runProgram(GLFWwindow* window)
{
    // Enable depth (Z) buffer (accept "closest" fragment)
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    // Configure miscellaneous OpenGL settings
    glEnable(GL_CULL_FACE);

    // Set default colour after clearing the colour buffer
    glClearColor(1.0f, 0.5f, 1.0f, 1.0f);

    //Eable alpha blending
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    // Set up your scene here (create Vertex Array Objects, etc.)

    Gloom::Shader shader;

    shader.makeBasicShader("/home/tord/cloudRepos/github/gloom/gloom/shaders/simple.vert",
                           "/home/tord/cloudRepos/github/gloom/gloom/shaders/simple.frag");

    std::vector<float> coordinates123 = {0.6, -0.8, -1.2,
                                     0.0,  0.4,  0.0,
                                     -0.8, -0.2,  1.2};


    //feeding the Vertex buffer object to the vertex array object
    std::vector<float> coordinates = {-0.8, 0.8, 0.5,
                                      0.2, -0.2, 0.5,
                                      0.0, 0.8, 0.5,

                                      0.5, 0.8, 0.0,
                                      -0.2, -0.2, 0.0,
                                      0.4, 0.2, 0.0,

                                      -0.2, 0.2, -0.5,
                                      0.1, -0.5, -0.5,
                                      0.4, 0.2, -0.5,
/*
                                      -0.8, 0.2, 0.0,
                                      -0.8, -0.5, 0.0,
                                      -0.6, -0.2, 0.0,

                                      0.5, 0.0, 0.0,
                                      0.5, -0.5, 0.0,
                                      0.8, 0.0, 0.0
*/                                     };

    std::vector<float> color = { 
                                 0.0, 0.0, 1.0, 0.5,
                                 0.0, 0.0, 1.0, 0.5,
                                 0.0, 0.0, 1.0, 0.5,
                                
                                
                                 1.0, 0.0, 0.0, 0.5,
                                 1.0, 0.0, 0.0, 0.5,
                                 1.0, 0.0, 0.0, 0.5,
                                
                                 0.0, 1.0, 0.0, 0.5,
                                 0.0, 1.0, 0.0, 0.5,
                                 0.0, 1.0, 0.0, 0.5,

/*
                                 1.0f, 0.0f, 0.0f, 0.5f,
                                 0.0f, 1.0f, 0.0f, 0.5f,
                                 0.0f, 0.0f, 1.0f, 0.5f,

                                 1.0f, 0.0f, 0.0f, 0.5f,
                                 0.0f, 1.0f, 0.0f, 0.5f,
                                 0.0f, 0.0f, 1.0f, 0.5f
*/                                 };



    std::vector<unsigned int> indices = {
                                        12,13,14,
                                        9,10,11,
                                        6,7,8,
                                        3,4,5,
                                        0,1,2,
                                        };




    int VertexArrayObject = vertexArrayObject(coordinates, color, indices);

//    float numTransform = 1.0f;

    float pi = 3.1415f;

    shader.activate();

    // Rendering Loop
    while (!glfwWindowShouldClose(window))
    {
        //glUniform1f(2, sinf(numTransform));
        //printGLError();
        //numTransform -= 0.01f;


        glm::mat4x4 identityMatrix = glm::mat4x4(1.0f);

        glm::mat4x4 translationMatrix = glm::translate(identityMatrix, position);

        glm::mat4x4 projectionMatrix = glm::perspective(
            glm::radians(90.0f), 
            (float) windowWidth/windowHeight, 
            1.0f, 
            100.0f);

        //yaw
        glm::mat4x4 yawMatrix = glm::rotate(identityMatrix, rotation[0], glm::vec3(0.0f,1.0f,0.0f));

        glm::mat4x4 pitchMatrix = glm::rotate(identityMatrix, rotation[1], glm::vec3(1.0f,0.0f,0.0f));

        glm::mat4x4 transformationMatrix = projectionMatrix*pitchMatrix*yawMatrix*translationMatrix*identityMatrix;

        glUniformMatrix4fv(3, 1, GL_FALSE, glm::value_ptr(transformationMatrix));

        // Clear colour and depth buffers
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


        // Draw your scene here
//        glBindVertexArray(VertexArrayObject);  //bind vertex array
//        printGLError();


        glDrawElements(
            GL_TRIANGLES,      //enum mode,
            9*3,                 //int count,
            GL_UNSIGNED_INT,  //enum type,
            0                 //void* indices
        );
        printGLError();


        // Handle other events
        glfwPollEvents();
        handleKeyboardInput(window);

        // Flip buffers
        glfwSwapBuffers(window);
    }
    shader.deactivate();
    shader.destroy();
}

int vertexArrayObject(std::vector<float> coordinates, std::vector<float> color, std::vector<unsigned int> indices){
        std::cout << "This is a string" << std::endl;

        float vertexSize = coordinates.size()*sizeof(float);
        float colorSize = color.size()*sizeof(float);

        //creating Vertex array object
        unsigned int array;
        unsigned int* arrayPointer = &array;
        glGenVertexArrays(1, arrayPointer); //generate vertex array
        printGLError();

        glBindVertexArray(array);  //bind vertex array
        printGLError();

        //Creating the vertex buffer object
        unsigned int buffer;
        unsigned int* bufferPointer = &buffer;
        glGenBuffers(1, bufferPointer);  //generating a buffer
        printGLError();

        glBindBuffer(GL_ARRAY_BUFFER, buffer); //binding the buffer
        printGLError();

        glBufferData(GL_ARRAY_BUFFER, vertexSize, coordinates.data(), GL_STATIC_DRAW);  //Piping the data in to the buffer
        printGLError();

        glVertexAttribPointer(
            0,        //unsigned int index,
            3,         //int size,
            GL_FLOAT,  //enum type,
            GL_FALSE,  //bool normalised,
            0,         //size_t stride,
            0          //void* pointer
        );
        printGLError();

        //enabeling the vertex buffer
        glEnableVertexAttribArray(0);
        printGLError();


        //Creating the vertex color buffer object
        unsigned int bufferColor;
        unsigned int* bufferColorPointer = &bufferColor;
        glGenBuffers(1, bufferColorPointer);  //generating a buffer
        printGLError();

        glBindBuffer(GL_ARRAY_BUFFER, bufferColor); //binding the buffer
        printGLError();

        glBufferData(GL_ARRAY_BUFFER, colorSize, color.data(), GL_STATIC_DRAW);  //Piping the data in to the buffer
        printGLError();

        glVertexAttribPointer(
            1,        //unsigned int index,
            4,         //int size,
            GL_FLOAT,  //enum type,
            GL_FALSE,  //bool normalised,
            0,         //size_t stride,
            0          //void* pointer
        );
        printGLError();

        //enabeling the color buffer
        glEnableVertexAttribArray(1);
        printGLError();

        int indicesSize = indices.size()*sizeof(unsigned int);

        //the index buffer
        unsigned int bufferIndex;
        unsigned int* bufferIndexPointer = &bufferIndex;
        glGenBuffers(1, bufferIndexPointer);  //generating a buffer
        printGLError();

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferIndex); //binding the buffer
        printGLError();

        glBufferData(GL_ELEMENT_ARRAY_BUFFER, indicesSize, indices.data(), GL_STATIC_DRAW);  //Piping the data in to the buffer
        printGLError();

        return array;

}

void handleKeyboardInput(GLFWwindow* window)
{    
    // Use escape key for terminating the GLFW window
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(window, GL_TRUE);
    }

    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
    {
        position[0] -= 0.01f; 
    }
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
    {
        position[0] += 0.01f; 
    }
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
    {
        position[1] -= 0.01f; 
    }
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
    {
        position[1] += 0.01f; 
    }
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
    {
        position[2] += 0.01f; 
    }
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
    {
        position[2] -= 0.01f; 
    }



    if (glfwGetKey(window, GLFW_KEY_H) == GLFW_PRESS)
    {
        rotation[0] -= 0.01f; 
    }
    if (glfwGetKey(window, GLFW_KEY_K) == GLFW_PRESS)
    {
        rotation[0] += 0.01f; 
    }
    if (glfwGetKey(window, GLFW_KEY_J) == GLFW_PRESS)
    {
        rotation[1] -= 0.01f; 
    }
    if (glfwGetKey(window, GLFW_KEY_U) == GLFW_PRESS)
    {
        rotation[1] += 0.01f; 
    }


}
