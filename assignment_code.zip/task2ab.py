import matplotlib.pyplot as plt
import os
import numpy
import math

image_output_dir = "image_processed"
os.makedirs(image_output_dir, exist_ok=True)


def save_im(imname, im, cmap=None):
    impath = os.path.join(image_output_dir, imname)
    plt.imsave(impath, im, cmap=cmap)


def greyscale(im):
    """ Converts an RGB image to greyscale
    
    Args:
        im ([type]): [np.array of shape [H, W, 3]]
    
    Returns:
        im ([type]): [np.array of shape [H, W]]
    """
    # YOUR CODE HERE
#    print(im.ndim)
#    print(im.shape)
#    print(im.size)
#    print(im.flags)

    newImage = []

    rowCounter = 0
    for rows in im:
        pixelCounter = 0
        rowPixels = []
        for pixel in rows:
            grayValue = (im[rowCounter][pixelCounter][0]*0.212) + (im[rowCounter][pixelCounter][1]*0.7152) + (im[rowCounter][pixelCounter][2]*0.0722)
            rowPixels.append(math.floor(grayValue))
            pixelCounter += 1
        newImage.append(rowPixels)
        rowCounter += 1
    im = newImage
    return im


def inverse(im):
    """ Finds the inverse of the greyscale image
    
    Args:
        im ([type]): [np.array of shape [H, W]]
    
    Returns:
        im ([type]): [np.array of shape [H, W]]
    """    
     # YOUR CODE HERE

    newImage = []

    rowCounter = 0
    for rows in im:
        pixelCounter = 0
        rowPixels = []
        for pixel in rows:
            inverseValues = 255 - im[rowCounter][pixelCounter]   
            print(inverseValues)    
            rowPixels.append(inverseValues)
            pixelCounter += 1
        newImage.append(rowPixels)
        rowCounter += 1
    im = newImage
    return im


if __name__ == "__main__":
    im = plt.imread("images/lake.jpg")
    im = greyscale(im)
    inverse_im = inverse(im)
    save_im("lake_greyscale.jpg", im, cmap="gray")
    save_im("lake_inverse.jpg", inverse_im, cmap="gray")
