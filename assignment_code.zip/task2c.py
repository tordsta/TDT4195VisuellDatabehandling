import numpy as np
import os
import matplotlib.pyplot as plt
from task2ab import save_im
import math


def convolve_im(im, kernel):
    """ A function that convolves im with kernel
    
    Args:
        im ([type]): [np.array of shape [H, W, 3]]
        kernel ([type]): [np.array of shape [K, K]]
    
    Returns:
        [type]: [np.array of shape [H, W, 3]. should be same as im]
    """
    # YOUR CODE HERE

    #rotete kernel
    kernel = np.rot90(kernel, 2)

    #making a padded image with the size of the image and padding of the kernel
    pad_im = np.zeros(
        shape=[ 
            im.shape[0] + kernel.shape[0] *2 , 
            im.shape[1] + kernel.shape[1] *2 , 
            3 
        ])

    print(pad_im)
    #inserts the image in the zero frame, with the start and end value
    pad_im[
        kernel.shape[0] : kernel.shape[0] + im.shape[0],
        kernel.shape[1] : kernel.shape[1] + im.shape[1]
    ] = im

    convolve_image = np.zeros(im.shape)


    convolve_image[0][0][0] = sum(
                    kernel*pad_im[
                        kernel.shape[0] + pixelNr : kernel.shape[0]*2 + pixelNr,
                        kernel.shape[1] + rowNr : kernel.shape[1]*2 + rowNr,
                        0:0
                    ]
                )

    channelNr = 0
    for channels in pad_im[0][0]:
        print(channels)


        rowNr = 0
        for rows in im[kernel.shape[1] : kernel.shape[1] + im.shape[1]]:            
            pixelNr = 0
            for pixels in rows[kernel.shape[0] : kernel.shape[0] + im.shape[0]]: #padded image itteration through all pixels
                #does not work because of the dimentional difference between kernel and pad_im
                """
                convolve_image[pixelNr][rowsNr][channelNr] = sum(
                    kernel*pad_im[
                        kernel.shape[0] + pixelNr : kernel.shape[0]*2 + pixelNr,
                        kernel.shape[1] + rowNr : kernel.shape[1]*2 + rowNr,
                        channelNr:channelNr
                    ]
                )
                """
                continue                

                pixelNr+=1
                #print(pixels) 
                #sum(kernel * padded image[range start])
            rowNr+=1
        channelNr+=1

    #    https://en.wikipedia.org/wiki/Kernel_(image_processing)



    """
    rowCounter = 0
    for rows in im:
        pixelCounter = 0
        RrowPixels = []
        GrowPixels = []
        BrowPixels = []
        for pixel in rows:
            red = im[rowCounter][pixelCounter][0]
            green = im[rowCounter][pixelCounter][1]
            blue = im[rowCounter][pixelCounter][2]        
            RrowPixels.append(red)
            GrowPixels.append(green)
            BrowPixels.append(blue)
            pixelCounter += 1
        redImg.append(RrowPixels)
        greenImg.append(GrowPixels)
        blueImg.append(BrowPixels)
        rowCounter += 1
    """

    return im


if __name__ == "__main__":
    # Read image
    impath = os.path.join("images", "lake.jpg")
    im = plt.imread(impath)

    # Define the convolutional kernels
    h_a = np.ones((3, 3)) / 9
    h_b = np.array([
        [1, 4, 6, 4, 1],
        [4, 16, 24, 16, 4],
        [6, 24, 36, 24, 6],
        [4, 16, 24, 16, 4],
        [1, 4, 6, 4, 1],
    ]) / 256
    # Convolve images
    smoothed_im1 = convolve_im(im.copy(), h_a)
    smoothed_im2 = convolve_im(im, h_b)

    # DO NOT CHANGE
    assert isinstance(smoothed_im1, np.ndarray), \
        f"Your convolve function has to return a np.array. " +\
        f"Was: {type(smoothed_im1)}"
    assert smoothed_im1.shape == im.shape, \
        f"Expected smoothed im ({smoothed_im1.shape}" + \
        f"to have same shape as im ({im.shape})"
    assert smoothed_im2.shape == im.shape, \
        f"Expected smoothed im ({smoothed_im1.shape}" + \
        f"to have same shape as im ({im.shape})"

    save_im("convolved_im_h_a.jpg", smoothed_im1)
    save_im("convolved_im_h_b.jpg", smoothed_im2)
