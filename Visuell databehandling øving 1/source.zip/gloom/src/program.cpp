// Local headers
#include "program.hpp"
#include "gloom/gloom.hpp"
#include <vector>
#include <iostream>
#include <GL/gl.h>
//#include <GL/glu.h>
//#include <GL/glut.h>
#include "gloom/gloom.hpp"
#include "gloom/shader.hpp"

void runProgram(GLFWwindow* window)
{
    // Enable depth (Z) buffer (accept "closest" fragment)
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);

    // Configure miscellaneous OpenGL settings
    glEnable(GL_CULL_FACE);

    // Set default colour after clearing the colour buffer
    glClearColor(1.0f, 0.5f, 1.0f, 1.0f);


    // Set up your scene here (create Vertex Array Objects, etc.)

    Gloom::Shader shader;

    shader.makeBasicShader("/home/tord/cloudRepos/github/gloom/gloom/shaders/simple.vert",
                           "/home/tord/cloudRepos/github/gloom/gloom/shaders/simple.frag");

    std::vector<float> coordinates123 = {0.6, -0.8, -1.2,
                                     0.0,  0.4,  0.0,
                                     -0.8, -0.2,  1.2};


    //feeding the Vertex buffer object to the vertex array object
    std::vector<float> coordinates = {-0.8, 0.8, 0.0,
                                      -0.4, 0.5, 0.0,
                                      0.0, 0.8, 0.0,

                                      0.5, 0.8, 0.0,
                                      0.4, 0.2, 0.0,
                                      0.6, 0.2, 0.0,

                                      -0.2, 0.2, 0.0,
                                      0.1, -0.5, 0.0,
                                      0.4, 0.2, 0.0,

                                      -0.8, 0.2, 0.0,
                                      -0.8, -0.5, 0.0,
                                      -0.6, -0.2, 0.0,

                                      0.5, 0.0, 0.0,
                                      0.5, -0.5, 0.0,
                                      0.8, 0.0, 0.0
                                     };




    std::vector<unsigned int> indices = {0,1,2,
                                        3,4,5,
                                        6,7,8,
                                        9,10,11,
                                        12,13,14};

    int VertexArrayObject = vertexArrayObject(coordinates, indices);


    // Rendering Loop
    while (!glfwWindowShouldClose(window))
    {
        // Clear colour and depth buffers
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Draw your scene here
        glBindVertexArray(VertexArrayObject);  //bind vertex array
        printGLError();

        shader.activate();

        glDrawElements(
            GL_TRIANGLES,      //enum mode,
            9*3,                 //int count,
            GL_UNSIGNED_INT,  //enum type,
            0                 //void* indices
        );
        printGLError();

        shader.deactivate();

        // Handle other events
        glfwPollEvents();
        handleKeyboardInput(window);

        // Flip buffers
        glfwSwapBuffers(window);
    }
    shader.destroy();
}

int vertexArrayObject(std::vector<float> coordinates, std::vector<unsigned int> indices){
        std::cout << "This is a string" << std::endl;

        float vertexSize = coordinates.size()*sizeof(float);

        //creating Vertex array object
        unsigned int array;
        unsigned int* arrayPointer = &array;
        glGenVertexArrays(1, arrayPointer); //generate vertex array
        printGLError();

        glBindVertexArray(array);  //bind vertex array
        printGLError();

        //Creating the vertex buffer object
        unsigned int buffer;
        unsigned int* bufferPointer = &buffer;
        glGenBuffers(1, bufferPointer);  //generating a buffer
        printGLError();

        glBindBuffer(GL_ARRAY_BUFFER, buffer); //binding the buffer
        printGLError();

        glBufferData(GL_ARRAY_BUFFER, vertexSize, coordinates.data(), GL_STATIC_DRAW);  //Piping the data in to the buffer
        printGLError();

        glVertexAttribPointer(
            0,        //unsigned int index,
            3,         //int size,
            GL_FLOAT,  //enum type,
            GL_FALSE,  //bool normalised,
            0,         //size_t stride,
            0          //void* pointer
        );
        printGLError();

        //enabeling the ABO
        glEnableVertexAttribArray(0);
        printGLError();


        int indicesSize = indices.size()*sizeof(unsigned int);

        //the index buffer
        unsigned int bufferIndex;
        unsigned int* bufferIndexPointer = &bufferIndex;
        glGenBuffers(1, bufferIndexPointer);  //generating a buffer
        printGLError();

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferIndex); //binding the buffer
        printGLError();

        glBufferData(GL_ELEMENT_ARRAY_BUFFER, indicesSize, indices.data(), GL_STATIC_DRAW);  //Piping the data in to the buffer
        printGLError();

        return array;

}



void handleKeyboardInput(GLFWwindow* window)
{
    // Use escape key for terminating the GLFW window
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(window, GL_TRUE);
    }
}
